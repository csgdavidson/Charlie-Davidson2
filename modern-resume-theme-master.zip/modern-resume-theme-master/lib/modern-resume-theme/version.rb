module ModernResumeTheme
  VERSION = "1.8.5"
end
